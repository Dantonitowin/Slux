made it for fun
